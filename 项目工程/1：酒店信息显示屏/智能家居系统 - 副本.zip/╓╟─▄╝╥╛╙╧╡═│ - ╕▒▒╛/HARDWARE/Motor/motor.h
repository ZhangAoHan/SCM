#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"

void TIM3_init(u16 arr,u16 psc);
#endif

