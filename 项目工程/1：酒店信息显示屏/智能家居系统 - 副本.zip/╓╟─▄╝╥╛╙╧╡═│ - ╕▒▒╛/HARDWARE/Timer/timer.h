#ifndef __TIMER_H
#define __TIMER_H	 
#include "sys.h"

#include "ds18b20.h"
#include "oled.h"

void TIM2_Int_Init(u16 arr,u16 psc);

#endif
