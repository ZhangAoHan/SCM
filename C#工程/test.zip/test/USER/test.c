#include "sys.h"
#include "usart.h"		
#include "delay.h"	
#include "led.h" 
#include "beep.h" 
#include "key.h"	 	 
#include "spi.h"
#include "dht11.h"
#include "pwm.h"
#include "stmflash.h"
//#include "rc522.h"

/*******************************
*����˵����
*1--SS  <----->PF0
*2--SCK <----->PB13
*3--MOSI<----->PB15
*4--MISO<----->PB14
*5--����
*6--GND <----->GND
*7--RST <----->PF1
*8--VCC <----->VCC
************************************/


//PWM		PB5 2 PB4 1	TIM3
//7670	VSYNV	PA8	WRST PD6 RRST PG14 OE PG15 WREN	PB3 RCK PB4 	
//SCCB	SCL PD3	SDA PG12

////LCD		BL PB2 CS PG12 RS PG0 WR PD5 RD PD4 
//////LCD DATA	E0-15
//u8 TEXT_Buffer[16]={0x52,0xCA,0x56,0x84,0x33,0x33,0x33,0x33,0,0,0,0,0,0,0,0};
//extern u8 TEXT_Buffer[];


//u8 TEXT1[]={0x52,0xCA,0x56,0x84};
//u8 TEXT2[]={0xF3,0x87,0xA1,0xB5};
//u8 TEXT3[]={0x4C,0x76,0xA1,0xB5};

unsigned char CT[2];//������
unsigned char SN[4]; //����
unsigned char SNE[4]; //����y




int main(void)
{					
//		u8 rr;
		u8 i,cl=0;
	Stm32_Clock_Init(9);	//ϵͳʱ������
	uart_init(72,115200); 	//���ڳ�ʼ��Ϊ115200
	delay_init(72);	   	 	//��ʱ��ʼ�� 


//	STMFLASH_ErasePage(FLASH_START_ADDR);
//  STMFLASH_Write(FLASH_START_ADDR,(u16*)TEXT_Buffer,sizeof(TEXT_Buffer));
//  STMFLASH_Write((FLASH_START_ADDR+0x8000),(u16*)TEXT_Buffer,SIZE/2);
	TIM3_Init(9999,143);		//PWM
	InitRc522();	
	Smoke_Init();
	Bee_Init();	
	Switch_Init();
	while(DHT11_Init())
	while(DHT12_Init())		
	TIM4_Init(3999,4999);				//20hz
 	while(1)
	{
//				rr=USART1->DR; 
		if(flag)
		{
					switch(res)
			{
				
				case 0xED:
				{
									flag=0;
									TIM4->CR1&=0xFE;	
									Bee_error();
									TIM4->CR1|=0x01;
								break;
				}
				case 0xEE:
				{
									flag=0;
									TIM4->CR1&=0xFE;	
									PWM_Ctrl(1,9000);
									
									for(i=0;i<50;i++)
								{
														delay_ms(40);
					
								}

									PWM_Ctrl(1,9600);
									TIM4->CR1|=0x01;
								break;
				}
				case 0xEA:
				{
								flag=0;
								TIM4->CR1&=0xFE;
					{
					if(cl)
					{
						PWM_Ctrl(2,9000);
						cl=0;						
					}

					 
					else
					{
						PWM_Ctrl(2,9600);
						cl=1;
					}

					}

					
								TIM4->CR1|=0x01;
					
				}
				default :break;
			
			}
		}

		
	}		 
}

void TIM4_IRQHandler(void)
{
	unsigned char status;	
//	u8 datatemp[SIZE];
	u8 temperature;  	    
	u8 humidity;  
  u8 i;
 	u8 s1,s2;
	u8 th[4];
		if(TIM4->SR&0x0001)
		{
			status = PcdRequest(PICC_REQALL,CT);/*ɨ�迨*/
			status = PcdAnticoll(SN);/*����ײ*/ //���ؿ���


			if (status==MI_OK)
			{
				status=MI_ERR;
//				printf(SN);
				printf("%c%c%s%c",0x01,0x0C,SN,0xFF);
				Reset_RC522();
				Bee_Success();
			}
			
			
			if (Smoke1==0)
			{
				delay_ms(30);
				if (Smoke1==0)
				{
					Bee_error();
					s1=0x01;
//					PWM_Ctrl(1,9000);
//					Switch1=0;
				}
			}
				else if(Smoke2==0)
			{
				delay_ms(30);
			if (Smoke2==0)
				{

					Bee_error();
					s2=0x01;
//					PWM_Ctrl(2,9000);
//					Switch2=0;
			}
				
			}
				else
			{
//				PWM_Ctrl(1,9600);
//				PWM_Ctrl(2,9600);			
//				Switch1=1;
//				Switch2=1;
					s1=0x02;
				  s2=0x02;
			}

			delay_ms(5);
			DHT11_Read_Data(&temperature,&humidity);
			if((temperature)|(humidity))
			{
			th[0]=0x30+(temperature/10%10);
			th[1]=0x30+(temperature%10);	
			th[2]=0x30+(humidity/10%10);
			th[3]=0x30+(humidity%10);	

			}
			

			printf("%c%c%c%c%c%c%c",0x0D,0x0A,th[0],th[1],th[2],th[3],s1);
			DHT12_Read_Data(&temperature,&humidity);
			th[0]=0x30+temperature/10;
			th[1]=0x30+temperature%10;	
			th[2]=0x30+humidity/10;
			th[3]=0x30+humidity%10;	
//			printf("%c%c%s%c",0x0D,0x0B,th,s2);		
			printf("%c%c%c%c%c%c%c",0x0D,0x0B,th[0],th[1],th[2],th[3],s2);			
		}
		
		
		
		TIM4->SR&=~(1<<0);
}
