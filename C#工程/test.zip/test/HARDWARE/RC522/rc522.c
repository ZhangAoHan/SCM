#include "rc522.h"



u8 Card_Num(u16 *pBuffer)
{
	u8 i;
	for(i=0;i<16;i++)
	{
		printf("%c",pBuffer[i]);
			if((pBuffer[i]==0)|(pBuffer[i]==0xFF)|(pBuffer[i]=='\0'))
		 break;
				
	}
//	printf((char*)pBuffer);

	return i;
	
}

void Card_Add(u8 ID[4],u16 *pBuffer)
{
	u8 i,num;
	num=Card_Num(pBuffer);
	if(num<4)
		for(i=0;i<4;i++)
	{
			pBuffer[(num*4)+i]=ID[i];		
	}
	printf((char*)pBuffer);
	  
}
u8 Card_Del(u8 ID[4],u16 *pBuffer)
{
  u8 i,j,f;
	for(i=0;i<16;i++)
	{
			if(pBuffer[i]==ID[1])
			{
					if(pBuffer[i+1]==ID[2])
					{
						  
							for(j=0;j<(12-i);j++)
						{
							pBuffer[i]=pBuffer[i+4];
						}
							pBuffer[12]=0;
							pBuffer[13]=0;
							pBuffer[14]=0;
							pBuffer[15]=0;						
							f=1;
							break;

					}
					else continue;
					
			}
			else continue;
	}
			
	if(f==1)
		return 1;
	else
		return 0;
}
void Card_Save(u16 *pBuffer)
{
			STMFLASH_ErasePage(FLASH_START_ADDR);
      STMFLASH_Write(FLASH_START_ADDR,(u16*)pBuffer,sizeof(pBuffer));
//			STMFLASH_ErasePage(FLASH_NUM_ADDR);
//      STMFLASH_Write(FLASH_START_ADDR,(u16*)NUM+0x30,sizeof(NUM+0x30));
}

void Card_Load(u16 *pBuffer)
{
//		 u8 datatemp[SIZE];
		 STMFLASH_Read(FLASH_START_ADDR,pBuffer,16);
}

u8 Card_Reg(u8 ID[4],u16 *pBuffer)
{
	u8 i,j;
		Card_Load(pBuffer);
	for(i=0;i<16;i++)
	{
			if(pBuffer[i]==ID[1])
			{
					if(pBuffer[i+1]==ID[2])
					{
						j=1;
						break;
					}
			}

	}			

	if(j==1)
		return 1;
	else return 0;
}
