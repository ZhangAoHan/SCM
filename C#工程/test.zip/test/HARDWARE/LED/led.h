#ifndef __LED_H
#define __LED_H	 
#include "sys.h"


//LED�˿ڶ���
//#define LED0 PBout(5)	// DS0
//#define LED1 PEout(5)	// DS1	

#define Switch1 PCout(0)
#define Switch2 PCout(1)
#define Smoke1 PAin(0)
#define Smoke2 PAin(1)


void LED_Init(void);	//��ʼ��	
void Bee_Init(void);
void Bee_Success(void);
void Bee_error(void);
void Smoke_Init(void);
void Switch_Init(void);


#endif

















