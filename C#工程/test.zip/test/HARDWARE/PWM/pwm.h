#ifndef	___PWM__H
#define	___PWM__H

#include "sys.h"
#include "delay.h"


void TIM3_Init(u16 arr,u16 psc);
void PWM_Ctrl(u8 port,u16 duty);
void TIM4_Init(u16 arr,u16 psc);


#endif
