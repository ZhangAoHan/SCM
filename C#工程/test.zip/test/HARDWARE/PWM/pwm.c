#include "pwm.h"

//TIM3 REMAP=10 PB4 PB5 PB0 PB1

void TIM3_Init(u16 arr,u16 psc)				//CNT ���� PSCԤ��Ƶ ARR�Զ���װ��   pwm_fre=fclk/(arr+1)(psc+1) pwm_duty=n/arr
{
		RCC->APB1ENR|=1<<1;				//TIM3CLK ENABLE
		RCC->APB2ENR|=1<<3;				//PINBCLK ENABLE
		GPIOB->CRL&=0xFF00FFFF;
	  GPIOB->CRL|=0x00BB0000;
	
		RCC->APB2ENR|=1<<0;
	  AFIO->MAPR&=0XF8FFF3FF; //���MAPR��[11:10][26:24]
		AFIO->MAPR|=1<<24;			//�ر�JTAG  SWJ_CFG=001		
		AFIO->MAPR|=1<<11;      //������ӳ��,TIM3_CH2->PB5
	
		TIM3->ARR=arr;					//4499 16khz ����Ƶ
		TIM3->PSC=psc;
	
		TIM3->CCMR1|=7<<12;  	//CH2 PWM2ģʽ		 
		TIM3->CCMR1|=1<<11; 	//CH2 Ԥװ��ʹ��	   

		TIM3->CCMR1|=7<<4;  	//CH1 PWM2ģʽ		 
		TIM3->CCMR1|=1<<3; 	//CH1 Ԥװ��ʹ��
	
//		TIM3->CCMR2|=7<<12;  	//CH4 PWM2ģʽ		 
//		TIM3->CCMR2|=1<<11; 	//CH4 Ԥװ��ʹ��	  

//		TIM3->CCMR2|=7<<4;  	//CH3 PWM2ģʽ		 
//		TIM3->CCMR2|=1<<3; 	//CH3 Ԥװ��ʹ��	
		
		TIM3->CCER|=0X1111;
		
		TIM3->CR1=0X0080;
		TIM3->CR1|=0X01;


						PWM_Ctrl(1,9000);
						PWM_Ctrl(2,9000);
//						PWM_Ctrl(3,999);
//						PWM_Ctrl(4,999);


}

void PWM_Ctrl(u8 port,u16 dut)
{		
		u16 duty;
		duty=dut;
		switch(port)
		{
		
			case 1:TIM3->CCR1=duty;break;
			case 2:TIM3->CCR2=duty;break;
			case 3:TIM3->CCR3=duty;break;
			case 4:TIM3->CCR4=duty;break;
			default:break;
		
		}
}

void TIM4_Init(u16 arr,u16 psc)					//600hz?
{
		
		RCC->APB1ENR|=1<<2;
		TIM4->ARR=arr;
		TIM4->PSC=psc;
	
		TIM4->DIER|=1<<0;
		TIM4->CR1|=0x01;				//ENABLE TIM4
//		TIM4->CR1&=0xFE;				//DISABLE TIM4
 		MY_NVIC_Init(2,1,TIM4_IRQn,2);				//��ռ ���� ��
}

void Door_Open(void)
{

}

void Door_Close(void)
{

}




