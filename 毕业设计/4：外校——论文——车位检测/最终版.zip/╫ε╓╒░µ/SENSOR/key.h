#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

#define ZD		PCin(0) //PE4


void KEY_Init(void);//IO��ʼ��
#endif
