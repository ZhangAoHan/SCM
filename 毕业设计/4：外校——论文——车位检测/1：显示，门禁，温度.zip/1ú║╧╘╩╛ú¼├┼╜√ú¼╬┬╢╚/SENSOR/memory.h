#ifndef __MEMORY_H__
#define __MEMORY_H__
#include "sys.h"       

void read_temp(void);
void temp_memory(void);

 
#endif
















