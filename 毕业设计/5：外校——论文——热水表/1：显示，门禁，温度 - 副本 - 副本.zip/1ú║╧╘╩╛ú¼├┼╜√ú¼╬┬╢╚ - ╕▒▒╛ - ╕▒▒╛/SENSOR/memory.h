#ifndef __MEMORY_H__
#define __MEMORY_H__
#include "sys.h"       

void readin_temp(void);
void tempin_memory(void);
void Temp_display(u8 y,u8 p);
void tempout_memory(void);
void readout_temp(void);
#endif
















